void func_1(int *pArr, int len, int *max, int *min) {

	int temp;

	*max = pArr[0];
	*min = pArr[0];

	for (int i = 1; i < len; i++) {
		if (*max < pArr[i]) {
			*max = pArr[i];
		}

		if (*min > pArr[i]) {
			*min = pArr[i];
	}

		return;
	}

}

void func_2(char * str, int len) {

	if (str[len] != '\0') {
		printf("�߸��� �Է°� ����\n");
		return;
	}

	int gap = 'a' - 'A';
	int i = 0;
	while (str[i] != '\0') {

		if (str[i] >= 'A' || str[i] <= 'Z') {
			str[i] += gap;
		}else if (str[i] >= 'a' || str[i] <= 'z') {
			str[i] -= gap;
		}
		else {
			printf("%c", str[i]);
		}
		i++;
	}
	
}

int main() {

	/* func_1 �׽�Ʈ*/
	//int arr[10] = { 1, 4,  5, 2, 8, 9, 10, 7, 6, 3 };
	//double avg;
	//int min, max;

	//func_1(arr, 10, &max, &min);


	/* func_2 �׽�Ʈ*/
	char str[] = "Hello";
	func_2(str, strlen(str));

	return 0;
}