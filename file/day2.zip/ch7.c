//#include<stdio.h>
//
//void func7_1() {
//	int i = 0;
//
//	while (i < 10) {
//
//		printf("hello moble\n");
//
//		i++;
//	}
//}
//
////1. hello moble
////2. hello moble
////3. hello moble
////4. hello moble
////5. hello moble
////6. hello moble
////7. hello moble
////8. hello moble
////9. hello moble
////10. hello moble
//void func7_2() {
//
//	int i = 0;
//
//	while (i < 10) {
//
//		printf("%d. hello moble\n", i+1);
//
//		i++;
//	}
//
//
//}
//
////5���� ������ �Է¹޾� �� ���� ���
////while ���� ����� ��
//void func7_3() {
//
//	int i=0, num, sum=0;
//
//	while (i < 5) {
//		scanf("%d", &num);
//		sum = sum + num;
//		i++;
//	}
//
//	printf("�Է��� ���� ��: %d", sum);
//
//}
////1���� 100������ ���� ���ϼ���
//void func7_4() {
//
//	int i = 0, sum = 0;
//
//	while (i < 100) {
//
//		sum += (i + 1);
//
//		i++;
//
//	}
//
//	printf("sum : %d", sum);
//}
//
//void func7_5() {
//	int i = 0, j = 0;
//	int num = 0;
//
//	while (i < 10) {
//		while (j < 10) {
//			num++;
//			j++;
//		}
//		i++;
//		j = 0;
//	}
//
//	printf("num: %d", num);
//
//}
//
////���� �ڵ��� ����� �����ϼ���
//void func7_6() {
//	int i = 0, j = 0;
//
//	while (i < 3) {
//		j = 0;
//		while (j < 5) {
//			printf("* ");
//			j++;
//		}
//		printf("\n");
//		i++;
//	}
//
//}
//
////*
////* *
////* * *
////* * * *
////* * * * *
//void func7_7() {
//	int i = 0, j = 0;
//
//	while (i < 5) {
//		j = 0;
//		while (j < i+1) {
//			printf("* ");
//			j++;
//		}
//		printf("\n");
//		i++;
//	}
//}
//
//void func7_8() {
//
//	int i = 0;
//
//	do{
//
//		printf("%d. hello moble\n", i + 1);
//
//		i++;
//	} while (i < 10);
//}
//
//void func7_9() {
//
//	int i = 1;
//	int num;
//
//	scanf("%d", &num);
//
//	while (i < 10) {
//		printf("%d x %d = %d \n", num, i, num*i);
//		i++;
//	}
//}
//
//void func7_10() {
//
//	int i = 2, j = 1;
//
//	while (i < 10) {
//
//		j = 1;
//		while (j < 10) {
//			printf("%d x %d = %d\n", i, j, i*j);
//			j++;
//		}
//
//		printf("\n");
//		i++;
//	}
//
//}
//
////8�� ���, for�� Ȱ��
//void func7_11() {
//	
//	for (int i = 1; i < 10; i++) {
//		printf(" 8 x %d = %d\n", i, 8 * i);
//	}
//}
//
////������ ���, forȰ��
//void func7_12() {
//
//	for (int i = 2; i < 10; i++) {
//
//		for (int j = 1; j < 10; j++) {
//			printf("%d x %d = %d\n", i, j, i*j);
//		}
//		printf("\n");
//	}
//}
//
//void func7_13() {
//
//	for (int i = 0; i < 10; i++) {
//
//		for (int j = 0; j < i + 1; j++) {
//			printf("* ");
//		}
//		printf("\n");
//
//	}
//}
//
//int main() {
//
//	func7_13();
//
//	return 0;
//}